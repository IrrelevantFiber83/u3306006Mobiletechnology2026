package com.example.assignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class EditActivity extends AppCompatActivity {

    EditText editTextReader;
    EditText editTextResult;

    ImageView imageView;

    Button buttonSave;

    String id;
    String reader;
    String result;
    String uri;

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit);

        editTextReader =
                findViewById(R.id.editTextReader);

        editTextResult =
                findViewById(R.id.editTextResult);

        imageView =
                findViewById(R.id.imageViewEdit);

        buttonSave =
                findViewById(R.id.buttonSave);

        databaseReference =
                FirebaseDatabase.getInstance()
                        .getReference("results");

        Intent intent = getIntent();

        id = intent.getStringExtra("id");

        reader = intent.getStringExtra("reader");

        result = intent.getStringExtra("result");

        uri = intent.getStringExtra("uri");

        editTextReader.setText(reader);

        editTextResult.setText(result);

        imageView.setImageURI(Uri.parse(uri));

        buttonSave.setOnClickListener(v -> {

            saveData();
        });
    }

    private void saveData() {

        String newReader =
                editTextReader.getText().toString();

        String newResult =
                editTextResult.getText().toString();

        if(id == null || id.isEmpty()) {

            id = UUID.randomUUID().toString();
        }

        MLKitResult item =
                new MLKitResult(
                        id,
                        newReader,
                        newResult,
                        uri
                );

        databaseReference
                .child(id)
                .setValue(item);

        Intent intent =
                new Intent(
                        EditActivity.this,
                        ListViewActivity.class
                );

        startActivity(intent);

        finish();
    }
}