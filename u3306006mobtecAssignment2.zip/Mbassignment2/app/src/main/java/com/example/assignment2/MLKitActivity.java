package com.example.assignment2;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;

import com.google.mlkit.vision.common.InputImage;

import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;

import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.List;

public class MLKitActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;

    private Uri imageFileUri;

    private ImageView imageView;
    private TextView textViewOutput;
    private TextView textViewTitle;
    private Button buttonEdit;

    private String readerType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_mlkit);

        imageView = findViewById(R.id.imageViewMLKit);
        textViewOutput = findViewById(R.id.textViewOutput);
        textViewTitle = findViewById(R.id.textViewMLKit);
        buttonEdit = findViewById(R.id.buttonEdit);

        readerType = getIntent().getStringExtra("reader_type");

        int imageRes = getIntent().getIntExtra("reader_image", 0);

        imageView.setImageResource(imageRes);
    }

    private boolean checkPermission() {

        String permission = android.Manifest.permission.CAMERA;

        boolean grantCamera =
                ContextCompat.checkSelfPermission(this, permission)
                        == PackageManager.PERMISSION_GRANTED;

        if (!grantCamera) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{permission},
                    REQUEST_PERMISSION
            );
        }

        return grantCamera;
    }

    public void openCamera(View view) {

        if (!checkPermission())
            return;

        Intent takePhotoIntent =
                new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        imageFileUri =
                getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        new ContentValues()
                );

        takePhotoIntent.putExtra(
                MediaStore.EXTRA_OUTPUT,
                imageFileUri
        );

        activityResultLauncher.launch(takePhotoIntent);
    }

    public void loadImage(View view) {

        Intent galleryIntent = new Intent(
                Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        );

        activityResultLauncher.launch(galleryIntent);
    }

    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),

                    result -> {

                        if (result.getResultCode() == RESULT_OK) {

                            if (result.getData() != null &&
                                    result.getData().getData() != null) {

                                imageFileUri =
                                        result.getData().getData();
                            }

                            imageView.setImageURI(imageFileUri);

                            textViewOutput.setText("");

                            InputImage image = null;

                            try {

                                image = InputImage.fromFilePath(
                                        getBaseContext(),
                                        imageFileUri
                                );

                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            if (image != null) {

                                switch (readerType) {

                                    case "BARCODE":
                                        processImageFromBarcodeReader(image);
                                        break;

                                    case "CONTENT":
                                        processImageFromContentReader(image);
                                        break;

                                    case "TEXT":
                                        processImageFromTextReader(image);
                                        break;
                                }
                            }
                        }
                    });

    public void processImageFromBarcodeReader(InputImage image) {

        textViewTitle.setText("Barcode Reader");

        BarcodeScannerOptions options =
                new BarcodeScannerOptions.Builder()
                        .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                        .build();

        BarcodeScanner scanner =
                BarcodeScanning.getClient(options);

        scanner.process(image)

                .addOnSuccessListener(barcodes -> {

                    buttonEdit.setVisibility(View.VISIBLE);

                    StringBuilder builder = new StringBuilder();

                    builder.append("Detected barcode:\n\n");

                    int count = 1;

                    for (Barcode barcode : barcodes) {

                        builder.append(count)
                                .append(". ")
                                .append(barcode.getRawValue())
                                .append("\n");

                        count++;
                    }

                    if (barcodes.size() == 0) {
                        builder.append("Barcode not found");
                    }

                    textViewOutput.setText(builder.toString());
                })

                .addOnFailureListener(e ->
                        textViewOutput.setText("Failed"));
    }

    public void processImageFromContentReader(InputImage image) {

        textViewTitle.setText("Content Reader");

        ImageLabelerOptions options =
                new ImageLabelerOptions.Builder()
                        .setConfidenceThreshold(0.7f)
                        .build();

        com.google.mlkit.vision.label.ImageLabeler labeler =
                ImageLabeling.getClient(options);

        labeler.process(image)

                .addOnSuccessListener(labels -> {

                    buttonEdit.setVisibility(View.VISIBLE);

                    StringBuilder builder = new StringBuilder();

                    builder.append("Recognised image content:\n\n");

                    int count = 1;

                    for (ImageLabel label : labels) {

                        builder.append(count)
                                .append(". ")
                                .append(label.getText())
                                .append("\n");

                        count++;
                    }

                    textViewOutput.setText(builder.toString());
                })

                .addOnFailureListener(e ->
                        textViewOutput.setText("Failed"));
    }

    public void processImageFromTextReader(InputImage image) {

        textViewTitle.setText("Text Reader");

        com.google.mlkit.vision.text.TextRecognizer recognizer =
                TextRecognition.getClient(
                        TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)

                .addOnSuccessListener(visionText -> {

                    buttonEdit.setVisibility(View.VISIBLE);

                    StringBuilder builder = new StringBuilder();

                    builder.append("Extracted text:\n\n");

                    String text = visionText.getText();

                    if (text.isEmpty()) {

                        builder.append("No text found");

                    } else {

                        String[] lines = text.split("\n");

                        for (int i = 0; i < lines.length; i++) {

                            builder.append(i + 1)
                                    .append(". ")
                                    .append(lines[i])
                                    .append("\n");
                        }
                    }

                    textViewOutput.setText(builder.toString());
                })

                .addOnFailureListener(e ->
                        textViewOutput.setText("Failed"));
    }

    public void openEdit(View view) {

        Intent intent =
                new Intent(
                        MLKitActivity.this,
                        EditActivity.class
                );

        intent.putExtra(
                "reader",
                textViewTitle.getText().toString()
        );

        intent.putExtra(
                "result",
                textViewOutput.getText().toString()
        );

        intent.putExtra(
                "uri",
                imageFileUri.toString()
        );

        startActivity(intent);
    }

}