package com.example.assignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DetailActivity extends AppCompatActivity {

    TextView textViewReader;
    TextView textViewResult;

    ImageView imageView;

    Button buttonEdit;
    Button buttonDelete;
    Button buttonCancel;

    String id;
    String reader;
    String result;
    String uri;

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_detail);

        textViewReader =
                findViewById(R.id.textViewReader);

        textViewResult =
                findViewById(R.id.textViewResult);

        imageView =
                findViewById(R.id.imageViewDetail);

        buttonEdit =
                findViewById(R.id.buttonEdit);

        buttonDelete =
                findViewById(R.id.buttonDelete);

        buttonCancel =
                findViewById(R.id.buttonCancel);

        databaseReference =
                FirebaseDatabase.getInstance()
                        .getReference("results");

        Intent intent = getIntent();

        id = intent.getStringExtra("id");

        reader = intent.getStringExtra("reader");

        result = intent.getStringExtra("result");

        uri = intent.getStringExtra("uri");

        textViewReader.setText(reader);

        textViewResult.setText(result);

        imageView.setImageURI(Uri.parse(uri));

        buttonEdit.setOnClickListener(v -> {

            Intent editIntent =
                    new Intent(
                            DetailActivity.this,
                            EditActivity.class
                    );

            editIntent.putExtra("id", id);

            editIntent.putExtra("reader", reader);

            editIntent.putExtra("result", result);

            editIntent.putExtra("uri", uri);

            startActivity(editIntent);
        });

        buttonDelete.setOnClickListener(v -> {

            databaseReference.child(id).removeValue();

            Intent listIntent =
                    new Intent(
                            DetailActivity.this,
                            ListViewActivity.class
                    );

            startActivity(listIntent);

            finish();
        });

        buttonCancel.setOnClickListener(v -> {

            Intent listIntent =
                    new Intent(
                            DetailActivity.this,
                            ListViewActivity.class
                    );

            startActivity(listIntent);

            finish();
        });
    }
}