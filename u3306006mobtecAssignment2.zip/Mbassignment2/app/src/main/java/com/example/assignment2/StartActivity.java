package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StartActivity extends AppCompatActivity {
    public static final String EXTRA_READER = "reader_type";
    public static final String EXTRA_IMAGE = "reader_image";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_start);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageButton buttonbar = findViewById(R.id.barcodebut);
        buttonbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartActivity.this, MLKitActivity.class);
                intent.putExtra(EXTRA_READER, "BARCODE");
                intent.putExtra(EXTRA_IMAGE, R.mipmap.barcode);
                startActivity(intent);
            }
        });
        ImageButton buttoncont = findViewById(R.id.contentreaderbut);
        buttoncont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartActivity.this, MLKitActivity.class);
                intent.putExtra(EXTRA_READER, "CONTENT");
                intent.putExtra(EXTRA_IMAGE, R.mipmap.contentreader);
                startActivity(intent);
            }
        });
        ImageButton buttonima = findViewById(R.id.imagetotextbut);
        buttonima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartActivity.this, MLKitActivity.class);
                intent.putExtra(EXTRA_READER, "TEXT");
                intent.putExtra(EXTRA_IMAGE, R.mipmap.imagetotext);
                startActivity(intent);
            }
        });
        Button buttonlistim = findViewById(R.id.listimagesbut);

        buttonlistim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent =
                        new Intent(
                                StartActivity.this,
                                ListViewActivity.class
                        );

                startActivity(intent);
            }
        });
    }
}