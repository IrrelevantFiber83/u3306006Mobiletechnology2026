package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ListViewActivity extends AppCompatActivity {

    ListView listView;

    Button buttonAdd;

    ArrayList<MLKitResult> mlKitResults;

    MLKitAdapter adapter;

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_list_view);

        listView = findViewById(R.id.listView);

        buttonAdd = findViewById(R.id.buttonAdd);

        mlKitResults = new ArrayList<>();

        adapter =
                new MLKitAdapter(
                        ListViewActivity.this,
                        R.layout.list_item,
                        mlKitResults
                );

        listView.setAdapter(adapter);

        databaseReference =
                FirebaseDatabase
                        .getInstance()
                        .getReference("results");

        loadData();

        buttonAdd.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            ListViewActivity.this,
                            StartActivity.class
                    );

            startActivity(intent);
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {

            MLKitResult item =
                    mlKitResults.get(position);

            Intent intent =
                    new Intent(
                            ListViewActivity.this,
                            DetailActivity.class
                    );

            intent.putExtra(
                    "id",
                    item.getId()
            );

            intent.putExtra(
                    "reader",
                    item.getReader()
            );

            intent.putExtra(
                    "result",
                    item.getResult()
            );

            intent.putExtra(
                    "uri",
                    item.getUri()
            );

            startActivity(intent);
        });
    }

    private void loadData() {

        databaseReference.addValueEventListener(
                new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot snapshot) {

                        mlKitResults.clear();

                        for(DataSnapshot data :
                                snapshot.getChildren()) {

                            MLKitResult item =
                                    data.getValue(
                                            MLKitResult.class
                                    );

                            mlKitResults.add(item);
                        }

                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {

                    }
                });
    }
}