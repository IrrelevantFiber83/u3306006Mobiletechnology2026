package com.example.assignment2;

public class MLKitResult {

    private String id;
    private String reader;
    private String result;
    private String uri;

    public MLKitResult() {
    }

    public MLKitResult(String id,
                       String reader,
                       String result,
                       String uri) {

        this.id = id;
        this.reader = reader;
        this.result = result;
        this.uri = uri;
    }

    public String getId() {
        return id;
    }

    public String getReader() {
        return reader;
    }

    public String getResult() {
        return result;
    }

    public String getUri() {
        return uri;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setReader(String reader) {
        this.reader = reader;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }
}